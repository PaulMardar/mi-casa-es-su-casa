from common import db

class Proposal(db.Model):
    __tablename__ = "proposal"

    id = db.Column(db.Integer,primary_key = True)
    name = db.Column(db.String(256), unique = True)
    createdBy = db.Column(db.String(257))
    question = db.Column(db.String(257))
    isFinished = db.Column(db.Boolean)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "createdBy": self.createdBy,
            "question": self.question,
                }
