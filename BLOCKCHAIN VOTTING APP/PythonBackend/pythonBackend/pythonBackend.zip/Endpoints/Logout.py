from flask import make_response
from flask_jwt import jwt_required
from flask_jwt_extended import create_access_token, get_jwt, unset_jwt_cookies
from flask_restful import Resource, reqparse

from Models.TokenBlacklist import TokenBlacklist
from Models.User import User
from common import db


class Logout(Resource):


    @jwt_required()
    def post(self):
        JTI = get_jwt().get("jti")
        expiration = get_jwt().get("exp")
        db.session.add(TokenBlacklist(expiration=expiration, token=JTI))
        db.session.commit()
        unset_jwt_cookies(make_response({"msg" : "Logout succesfull"}))
        return {"msg" : "Logout succesfull"}






