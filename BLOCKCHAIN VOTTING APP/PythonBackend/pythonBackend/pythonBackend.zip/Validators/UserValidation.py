

class UserValidator:


    pass