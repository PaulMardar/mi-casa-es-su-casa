
class ReferendumValidator():
    pass