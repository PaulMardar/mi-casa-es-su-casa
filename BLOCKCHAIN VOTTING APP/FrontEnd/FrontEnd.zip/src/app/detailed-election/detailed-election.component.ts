import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailed-election',
  templateUrl: './detailed-election.component.html',
  styleUrls: ['./detailed-election.component.css']
})
export class DetailedElectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
