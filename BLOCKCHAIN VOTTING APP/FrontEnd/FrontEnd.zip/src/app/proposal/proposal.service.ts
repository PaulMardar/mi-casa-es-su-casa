import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, of, tap } from 'rxjs';
import { Proposal } from './proposal';

@Injectable({
  providedIn: 'root'
})
export class ProposalService {


  private heroesUrl = 'http://localhost:5000/proposals';

  getProposals(): Observable<Proposal[]> {
    console.log(this.http.get<Proposal[]>(this.heroesUrl));
    return this.http.get<Proposal[]>(this.heroesUrl)
    .pipe(
      tap(_ => this.log('fetched Referendums')),
      catchError(this.handleError<Proposal[]>('getHeroes', []))
    );
  }
  log(arg0: string): void {
    console.log(arg0);
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  getProposadId(id: number | string) {
  return this.getProposals().pipe(
    map((p: Proposal[]) => p.find(x => x.id === +id)!)
  );
  }


  constructor(private http: HttpClient) { }

 
}
