export interface Proposal {
    id: number;
    name: string;
    createdBy: string;
    question: string;
  }