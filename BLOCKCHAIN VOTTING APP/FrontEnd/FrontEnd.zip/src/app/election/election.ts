export interface Election {
    id: number;
    electionName: string;
    position: string;
    candidates: string[];
  }